<?php
return [
	'productcatalogue_module' => 'পণ্য ক্যাটালগ মডিউল',
	'catalogue_qr' => 'ক্যাটালগ QR',
	'generate_qr' => 'QR জেনারেট করুন',
	'select_business_location' => 'ব্যবসার অবস্থান নির্বাচন করুন',
	'download_image' => 'ছবি ডাউনলোড করুন',
	'qr_code_color' => 'Qr কোড রঙ',
];