<?php
 return [
"printers" => "Impresoras",
"add_printer" => "Agregar impresora",
"name" => "Nombre de la impresora",
"connection_type" => "Tipo de conexión", /* modified */
"capability_profile" => "Perfil de capacidad",
"ip_address" => "Dirección IP",
"port" => "Puerto",
"path" => "Ruta", /* modified */
"added_success" => "Impresora agregada con éxito",
"manage_your_printers" => "Administre sus impresoras",
"all_your_printer" => "Todas las impresoras configuradas",
"deleted_success" => "Impresora eliminada con éxito",
"edit_printer_setting" => "Editar configuración de impresora",
"receipt_printers" => "Impresoras de tickets", /* modified */
"character_per_line" => "Caracteres por línea", /* modified */
"printer_name" => "Nombre de la impresora",
"updated_success" => "Impresora actualizada con éxito",
"edit_printer" => "Editar impresora",
];
