<?php
 return [
"product" => "Produkt",
"qty" => "Menge",
"unit_price" => "Einzelpreis",
"subtotal" => "Zwischensumme",
"discount" => "Rabatt",
"tax" => "MwSt",
"total" => "Gesamt",
"invoice_number" => "Rechnungsnummer",
"date" => "Datum",
"receipt_settings" => "Empfangseinstellungen",
"receipt_settings_mgs" => "Alle empfangsbezogenen Einstellungen für diesen Standort",
"print_receipt_on_invoice" => "Rechnung nach Abschluss automatisch drucken",
"receipt_printer_type" => "Belegdruckertyp",
"receipt_settings_updated" => "Boneinstellung erfolgreich aktualisiert",
];
