<?php
 return [
"product" => "Produkt",
"qty" => "Sasi",
"unit_price" => "Çmimi i njësisë",
"subtotal" => "Nëntotali",
"discount" => "Discount",
"tax" => "Tax",
"total" => "Total",
"invoice_number" => "Numri i fatures.",
"date" => "Data",
"receipt_settings" => "Cilësimet e marrjes",
"receipt_settings_mgs" => "Të gjitha cilësimet e lidhura me marrjen për këtë vend",
"print_receipt_on_invoice" => "Fatura automatike e printimit pas finalizimit",
"receipt_printer_type" => "Lloji i printerit të pranimit",
"receipt_settings_updated" => "Vendosja e faturave të përditësuara me sukses",
];
