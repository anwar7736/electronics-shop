<!-- model id like project_id, user_id -->
<input type="hidden" name="notable_id" id="notable_id" value="{{$contact->id}}">
<!-- model name like App\User -->
<input type="hidden" name="notable_type" id="notable_type" value="App\Contact">
<div class="document_note_body">
</div>