<script type="text/javascript">
	$(document).ready(function(){
	    getDocAndNoteIndexPage();
	    setTimeout(() => {
	        initializeDocumentAndNoteDataTable();
	    }, 200);
	});
</script>
